<!doctype html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Consulta de rubros</title>
</head>

<body>
  <form method="post" action="pagina2.php">
    Ingrese el código de rubro a consultar:
    <input type="text" name="codigo" size="10" required>
    <br>
    <input type="submit" value="Consultar">
  </form>
</body>

</html>